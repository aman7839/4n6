<ul class="nested">
    <?php $__currentLoopData = $childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <li>

    <span class="caret <?php echo e(count($category['nested_categories']) == 0 ? 'empty_folder': ''); ?>"><i class="fa fa-folder-open"></i> </span>
   <span class="tree_folder tree_folder_name tree_folder_editname"  data-name="<?php echo e($category['name']); ?>" data-id="<?php echo e($category['id']); ?>"><?php echo e($category["name"]); ?></span>
   <?php if(count($category["nested_categories"])>0): ?>
   <?php echo $__env->make('admin.vault.manageChild',['childs' => $category['nested_categories']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php endif; ?>
   </li>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH D:\xampp\htdocs\4n6\resources\views/admin/vault/manageChild.blade.php ENDPATH**/ ?>