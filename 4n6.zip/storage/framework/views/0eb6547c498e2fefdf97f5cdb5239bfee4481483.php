<!DOCTYPE html>
<html lang="en">
   

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>4n6</title>
    <link rel="stylesheet" href="<?php echo e(asset('/public/css/style.css')); ?>">
   

    <link rel="stylesheet" href="<?php echo e(asset('/public/4n61/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/public/css/font.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/public/4n61/css/steps.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/public/css/toast.css')); ?>">


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body>
    <!-- Header starts  herer -->
    <header>
        <div class="custom_container">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/public/4n61/images/fanatic_logo.svg')); ?>" alt=""></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll"
                    aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarScroll">
                    <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
                        <li class="nav-item ">
                            <a class="nav-link <?php echo e(request()->is('/') ? 'active' : ''); ?>" aria-current="page" href="<?php echo e(url('/')); ?>">Home</a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link <?php echo e(request()->is('regeneratetopics') ? 'active' : ''); ?>" href="<?php echo e(url('/regeneratetopics')); ?>">IDA</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->is('tutorial') ? 'active' : ''); ?>" href="<?php echo e(url('tutorial')); ?>">Tutorial</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->is('school') ? 'active' : ''); ?>" href="<?php echo e(url('school')); ?>">4N6 USA</a>
                        </li>
                        <li class="nav-item">
                            
                            <a class="nav-link  <?php echo e(request()->is('contactUs') ? 'active' : ''); ?>" href="<?php echo e(url('contactUs')); ?>">Contact Us</a>
                        </li>

                        <li class="nav-item">
                            
                            <a class="nav-link  <?php echo e(request()->is('demosearch') ? 'active' : ''); ?>" href="<?php echo e(url('demosearch')); ?>">Demo Search</a>
                        </li>
                        <div class="navigates mobile">
                            <a href="#" class="facebook_link"><img src="<?php echo e(asset('/public/4n61/images/facebook-square.svg')); ?>"></a>
                            <a href="<?php echo e(url('login')); ?>" class="cmn_btn">Member Login</a>
                            <a href="<?php echo e(url('login')); ?>" class="cmn_btn">Logout</a>
                        </div>

                    </ul>

                </div>
                <div class="navigates desktop">

                   <?php if(!Auth::user()): ?>
                    <a href="#" class="facebook_link"><img src="<?php echo e(asset('/public/4n61/images/facebook-square.svg')); ?>"></a>
                    <a href="<?php echo e(url('login')); ?>" class="cmn_btn">Member Login</a>
            <?php endif; ?>
                    <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()): ?>

                         <a href="<?php echo e(url('logout')); ?>" class="cmn_btn">Logout</a>
                    
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
            </nav>
        </div>
    </header>

    <!-- Header ends here --><?php /**PATH D:\xampp\htdocs\4n6\resources\views/frontendviews/navbar.blade.php ENDPATH**/ ?>