
<?php echo $__env->make('frontendviews.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('frontendviews.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>








<?php /**PATH D:\xampp\htdocs\4n6\resources\views/frontendviews/main.blade.php ENDPATH**/ ?>