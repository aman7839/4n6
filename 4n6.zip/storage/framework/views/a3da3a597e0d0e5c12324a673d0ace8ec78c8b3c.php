

    

    <?php $__env->startSection('content'); ?>

    <div class="container pb-4 pt-4">
        <div class="row m-2">
            

                
            </form>
            <div class="col-md-12 mt-2">
                <div class="card">
                    <div class="card-header">
                        <h4><a href="<?php echo e(url('admin/addstates')); ?>"  class="btn btn-primary btn-sm mt-2"><i class="fa fa-plus mr-2"></i> Add States</a></h4>
                        
                        
                        
                    </div>
                    <div class="card-body">     
    
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th> State Name</th>
                                     
                                    <th>File Name</th> 
                                    
                                
                                    <th>Edit</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    
                                    <td><img src= "" width="30%" class=" rounded-circle "  title=""><?php echo e($item->file); ?></td>
                                  
                                  
                                    
                                    
                                   
                                    <td>
                                        <a href=<?php echo e(url('admin/editstate/'.$item->id)); ?> class="btn btn-primary btn-sm">Edit</a>
                                    </td>
                                    <td>
                                        
                                        <a href=<?php echo e(url('admin/deletestate/'.$item->id)); ?> class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')" >Delete</a>
                                        
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            
                        </table>
                        <span><?php echo e($state->Links()); ?></span>
                        <style>
                            .w-5{
                                display:none;

                            }
                         </style> 

                         
    
                    </div>  
                   
                </div>
            </div>
        </div>
    </div>
   
    <?php $__env->stopSection(); ?>
 

<?php echo $__env->make('admin.dashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\4n6\resources\views/admin/States/states.blade.php ENDPATH**/ ?>