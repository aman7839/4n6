<div id="right-panel" class="right-panel">

    <!-- Header-->

    <header id="header" class="header">

        <div class="top-left">

            <div class="navbar-header">

                <a class="navbar-brand" href="./"><img src="<?php echo e(asset('/public/images/fanatic_logo.svg')); ?>" alt="Logo"></a>

                <a class="navbar-brand hidden" href="./"><img src="<?php echo e(asset('/public/images/logo2.png')); ?>" alt="Logo"></a>

                

            </div>

        </div>

            <div class="top-right">

                <div class="header-menu">

                    <div class="header-left">

                        

                        <div class="form-inline">

                            <form class="search-form">

                                <input class="form-control mr-sm-2" type="text" placeholder="Search ..." aria-label="Search">

                                <button class="search-close" type="submit"><i class="fa fa-close"></i></button>

                            </form>

                        </div>



                    

                        

                    



                    

                            

                            

                                

                                    

                                

                                

                            

                            

                                

                                

                            

                                

                            

                



                <div class="user-area dropdown float-right">

                    <a href="#" class="dropdown-toggle active" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                        <img class="user-avatar rounded-circle" src="<?php echo e(asset('/public/images/'. Auth::user()->image)); ?>" alt="User Avatar">

                    </a>

                    

                    





                    



                        

                </div>



            </div>

        </div>

    </header>

    <!-- /#header --><?php /**PATH D:\xampp\htdocs\4n6\resources\views/admin/dashboard/layout/sidebar.blade.php ENDPATH**/ ?>