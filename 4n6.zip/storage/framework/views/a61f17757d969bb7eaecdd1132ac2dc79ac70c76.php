

    

    <?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row m-2">
           <div class="col-md-12">
            
           </div>
            <div class="col-md-12 mt-2">
                <div class="card">
                    <div class="card-header">
                    <a href="<?php echo e(url('admin/adddata')); ?>"  class="btn btn-primary btn-sm mt-3"> <i class="fa fa-plus mr-2"></i> Add Data</a>

                       <a href="<?php echo e(url('/admin/topicroles')); ?>" class="btn btn-primary btn-sm mt-3">IDA Manager</a>
                        <a href="<?php echo e(url('/admin/viewisg')); ?>" class="btn btn-primary btn-sm mt-3">ISG Manager</a>
                      <a href="<?php echo e(url('/admin/extemp')); ?>" class="btn btn-primary btn-sm mt-3">Extemp Manager</a>


                        
                        
                    </div>
                    <div class="card-body">     
    
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th> Title</th>
                                     
                                    <th>Author</th> 
                                    <th>Category Name</th>                                      
                                    <th>Award Name</th>                                      
                                    <th>Theme Name</th>  
                                    <th>Public</th>  


                                    
                                    <th>Edit</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->title); ?></td>
                                    <td><?php echo e($item->author); ?></td>
                                    
                                    <td><?php echo e($item->category['name'] ?? ''); ?></td>

                                    <td><?php echo e($item->awards['awards_name'] ?? ''); ?></td>


                                    <td><?php echo e($item->theme['name'] ?? ''); ?></td> 
                                    <td><?php echo e($item->public ? 'Public' : 'Hidden'); ?></td>



                                  
                                  
                                   
                                    <td>
                                        <a href=<?php echo e(url('admin/editdata/'.$item->id)); ?> class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                        </a>
                                    </td>
                                    <td>
                                        
                                        <a href=<?php echo e(url('admin/deletedata/'.$item->id)); ?> class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')" ><i class="fa fa-trash" aria-hidden="true"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            
                        </table>
                        <span><?php echo e($data->Links()); ?></span>
                        <style>
                            .w-5{
                                display:none;

                            }
                         </style> 

                         
    
                    </div>  
                   
                </div>
            </div>
        </div>
    </div>
   
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\4n6\resources\views/admin/Data/data.blade.php ENDPATH**/ ?>