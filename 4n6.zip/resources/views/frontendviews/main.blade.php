
@include('frontendviews.navbar')
@yield('content')
@include('frontendviews.footer')








