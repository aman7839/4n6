@include('admin.dashboard.layout.navbar')

@include('admin.dashboard.layout.sidebar')

@yield('content')


@include('admin.dashboard.layout.footer')
@yield('footer-scripts')
